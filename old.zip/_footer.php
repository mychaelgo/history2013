					</div>
				</div>
				<div id="footer" class="menu">Copyright &copy; HIMTI BINUS University 2013</div>
			</div>
		</div>
	</body>
</html>